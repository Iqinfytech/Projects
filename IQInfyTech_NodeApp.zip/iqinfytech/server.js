// server.js  –  IQInfyTech Production Node.js Application
require('dotenv').config();

const express        = require('express');
const session        = require('express-session');
const flash          = require('connect-flash');
const helmet         = require('helmet');
const morgan         = require('morgan');
const methodOverride = require('method-override');
const path           = require('path');
const fs             = require('fs');

const app = express();

// ── Ensure upload dirs exist ────────────────────────────────
const uploadDirs = ['public/uploads/resumes', 'public/uploads/images', 'logs'];
uploadDirs.forEach(d => {
  const full = path.join(__dirname, d);
  if (!fs.existsSync(full)) fs.mkdirSync(full, { recursive: true });
});

// ── View engine ─────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ── Security ────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc:   ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc:    ["'self'", 'https://fonts.gstatic.com'],
      scriptSrc:  ["'self'", "'unsafe-inline'"],
      imgSrc:     ["'self'", 'data:', 'https:'],
    },
  },
}));

// ── Logging ─────────────────────────────────────────────────
if (process.env.NODE_ENV === 'production') {
  const accessLog = fs.createWriteStream(path.join(__dirname, 'logs/access.log'), { flags: 'a' });
  app.use(morgan('combined', { stream: accessLog }));
} else {
  app.use(morgan('dev'));
}

// ── Body parsing ─────────────────────────────────────────────
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.json({ limit: '10mb' }));
app.use(methodOverride('_method'));

// ── Static files ─────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: process.env.NODE_ENV === 'production' ? '7d' : 0,
}));

// ── Session ──────────────────────────────────────────────────
app.use(session({
  secret:            process.env.SESSION_SECRET || 'iqinfytech_dev_secret_change_me',
  resave:            false,
  saveUninitialized: false,
  cookie: {
    secure:   process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge:   8 * 60 * 60 * 1000, // 8 hours
  },
}));

// ── Flash messages ────────────────────────────────────────────
app.use(flash());

// ── Global template locals ────────────────────────────────────
app.use((req, res, next) => {
  res.locals.currentUser = req.session.user || null;
  res.locals.appName     = process.env.APP_NAME || 'IQInfyTech';
  next();
});

// ── Routes ────────────────────────────────────────────────────
app.use('/',       require('./routes/site'));
app.use('/admin',  require('./routes/auth'));
app.use('/admin',  require('./routes/admin'));

// ── 404 handler ───────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).render('error', {
    title:   '404 Not Found',
    code:    404,
    message: 'The page you are looking for does not exist.',
    user:    req.session.user || null,
  });
});

// ── Global error handler ──────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', {
    title:   'Server Error',
    code:    500,
    message: process.env.NODE_ENV === 'production' ? 'Something went wrong.' : err.message,
    user:    req.session.user || null,
  });
});

// ── Start ─────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🚀  IQInfyTech server running`);
  console.log(`   Local:   http://localhost:${PORT}`);
  console.log(`   Admin:   http://localhost:${PORT}/admin/login`);
  console.log(`   Mode:    ${process.env.NODE_ENV || 'development'}\n`);
});

module.exports = app;
