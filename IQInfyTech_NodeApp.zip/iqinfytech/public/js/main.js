// public/js/main.js
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', function (e) {
    const t = document.querySelector(this.getAttribute('href'));
    if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth' }); }
  });
});

function openApply(jobId, jobTitle) {
  document.getElementById('applyJobId').value = jobId;
  document.getElementById('applyJobTitle').textContent = jobTitle;
  document.getElementById('applyModal').style.display = 'flex';
}

document.getElementById('applyModal')?.addEventListener('click', function (e) {
  if (e.target === this) this.style.display = 'none';
});

// Auto-dismiss flash after 5s
const flash = document.querySelector('.site-flash');
if (flash) {
  setTimeout(() => { flash.style.opacity = '0'; flash.style.transition = 'opacity .5s'; }, 4500);
  setTimeout(() => flash.remove(), 5100);
}
