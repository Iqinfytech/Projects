// public/js/admin.js

// Sidebar toggle on mobile
document.addEventListener('DOMContentLoaded', () => {

  // Close sidebar when clicking outside on mobile
  document.addEventListener('click', (e) => {
    const sidebar = document.getElementById('sidebar');
    const toggle  = document.querySelector('.sidebar-toggle');
    if (sidebar && sidebar.classList.contains('open') &&
        !sidebar.contains(e.target) && e.target !== toggle) {
      sidebar.classList.remove('open');
    }
  });

  // Auto-dismiss flash messages
  document.querySelectorAll('.flash').forEach(el => {
    setTimeout(() => {
      el.style.transition = 'opacity .5s';
      el.style.opacity = '0';
    }, 4000);
    setTimeout(() => el.remove(), 4600);
  });

  // Auto-generate slug from title inputs
  document.querySelectorAll('input[name="title"], input[name="name"]').forEach(titleInput => {
    const form    = titleInput.closest('form');
    const slugInput = form ? form.querySelector('input[name="slug"]') : null;
    if (!slugInput) return;
    titleInput.addEventListener('input', () => {
      if (slugInput.dataset.manual) return;
      slugInput.value = titleInput.value
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .trim()
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-');
    });
    slugInput.addEventListener('input', () => { slugInput.dataset.manual = '1'; });
  });
});

// Toggle collapsible form panels
function toggleForm(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const isHidden = el.style.display === 'none' || el.style.display === '';
  el.style.display = isHidden ? 'block' : 'none';
  if (isHidden) el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}
