// routes/site.js
const express = require('express');
const router  = express.Router();
const multer  = require('multer');
const path    = require('path');
const site    = require('../controllers/siteController');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'public/uploads/resumes'),
  filename:    (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g, '_')),
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

router.get('/',             site.home);
router.post('/contact',     site.postContact);
router.post('/apply',       upload.single('resume'), site.postApply);

module.exports = router;
