// routes/auth.js
const express = require('express');
const router  = express.Router();
const auth    = require('../controllers/authController');
const { guestOnly, requireLogin } = require('../middleware/auth');

router.get('/login',  guestOnly,    auth.getLogin);
router.post('/login', guestOnly,    auth.postLogin);
router.get('/logout', requireLogin, auth.logout);

module.exports = router;
