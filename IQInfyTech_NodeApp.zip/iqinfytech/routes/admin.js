// routes/admin.js
const express  = require('express');
const router   = express.Router();
const db       = require('../config/db');
const admin    = require('../controllers/adminController');
const { requireLogin, requireRole } = require('../middleware/auth');

// All admin routes require login
router.use(requireLogin);

// Dashboard
router.get('/dashboard', admin.dashboard);

// ── Enquiries ────────────────────────────────────────────────
router.get('/enquiries',                  admin.listEnquiries);
router.post('/enquiries/:id/status',      admin.updateEnquiryStatus);

// ── Applications ─────────────────────────────────────────────
router.get('/applications',               admin.listApplications);
router.post('/applications/:id/status',   admin.updateAppStatus);

// ── Users (superadmin only) ───────────────────────────────────
router.get('/users',    requireRole('superadmin'), admin.listUsers);
router.post('/users',   requireRole('superadmin'), admin.createUser);
router.post('/users/:id/toggle', requireRole('superadmin'), admin.toggleUser);

// ── Services CRUD ─────────────────────────────────────────────
router.get('/services', async (req, res) => {
  const [rows] = await db.execute('SELECT * FROM services ORDER BY sort_order');
  res.render('admin/services', {
    title: 'Services', user: req.session.user, services: rows,
    messages: { success: req.flash('success'), error: req.flash('error') },
  });
});
router.post('/services', async (req, res) => {
  const { title, slug, icon, short_desc, tags, sort_order } = req.body;
  try {
    await db.execute('INSERT INTO services (title,slug,icon,short_desc,tags,sort_order) VALUES (?,?,?,?,?,?)',
      [title, slug, icon || '💻', short_desc, tags, parseInt(sort_order) || 0]);
    req.flash('success', 'Service added.');
  } catch (e) { req.flash('error', 'Slug already exists.'); }
  res.redirect('/admin/services');
});
router.post('/services/:id/delete', requireRole('superadmin','admin'), async (req, res) => {
  await db.execute('DELETE FROM services WHERE id=?', [req.params.id]);
  req.flash('success', 'Service deleted.');
  res.redirect('/admin/services');
});
router.post('/services/:id/toggle', async (req, res) => {
  await db.execute('UPDATE services SET is_active=NOT is_active WHERE id=?', [req.params.id]);
  res.redirect('/admin/services');
});

// ── Products CRUD ─────────────────────────────────────────────
router.get('/products', async (req, res) => {
  const [rows] = await db.execute('SELECT * FROM products ORDER BY sort_order');
  res.render('admin/products', {
    title: 'Products', user: req.session.user, products: rows,
    messages: { success: req.flash('success'), error: req.flash('error') },
  });
});
router.post('/products', async (req, res) => {
  const { name, slug, badge, tagline, description, features } = req.body;
  const featsArr = features.split('\n').map(f => f.trim()).filter(Boolean);
  try {
    await db.execute('INSERT INTO products (name,slug,badge,tagline,description,features) VALUES (?,?,?,?,?,?)',
      [name, slug, badge, tagline, description, JSON.stringify(featsArr)]);
    req.flash('success', 'Product added.');
  } catch (e) { req.flash('error', 'Slug already exists.'); }
  res.redirect('/admin/products');
});
router.post('/products/:id/delete', requireRole('superadmin','admin'), async (req, res) => {
  await db.execute('DELETE FROM products WHERE id=?', [req.params.id]);
  req.flash('success', 'Product deleted.');
  res.redirect('/admin/products');
});

// ── Portfolio CRUD ────────────────────────────────────────────
router.get('/portfolio', async (req, res) => {
  const [rows] = await db.execute('SELECT * FROM portfolio ORDER BY sort_order');
  res.render('admin/portfolio', {
    title: 'Portfolio', user: req.session.user, portfolio: rows,
    messages: { success: req.flash('success'), error: req.flash('error') },
  });
});
router.post('/portfolio', async (req, res) => {
  const { title, slug, industry, emoji, summary, result_1_val, result_1_lbl, result_2_val, result_2_lbl } = req.body;
  try {
    await db.execute(
      'INSERT INTO portfolio (title,slug,industry,emoji,summary,result_1_val,result_1_lbl,result_2_val,result_2_lbl) VALUES (?,?,?,?,?,?,?,?,?)',
      [title, slug, industry, emoji || '🏢', summary, result_1_val, result_1_lbl, result_2_val, result_2_lbl]);
    req.flash('success', 'Case study added.');
  } catch (e) { req.flash('error', 'Slug already exists.'); }
  res.redirect('/admin/portfolio');
});
router.post('/portfolio/:id/delete', requireRole('superadmin','admin'), async (req, res) => {
  await db.execute('DELETE FROM portfolio WHERE id=?', [req.params.id]);
  req.flash('success', 'Case study deleted.');
  res.redirect('/admin/portfolio');
});

// ── Team CRUD ─────────────────────────────────────────────────
router.get('/team', async (req, res) => {
  const [rows] = await db.execute('SELECT * FROM team_members ORDER BY sort_order');
  res.render('admin/team', {
    title: 'Team', user: req.session.user, members: rows,
    messages: { success: req.flash('success'), error: req.flash('error') },
  });
});
router.post('/team', async (req, res) => {
  const { name, initials, role, bio, experience, sort_order } = req.body;
  await db.execute('INSERT INTO team_members (name,initials,role,bio,experience,sort_order) VALUES (?,?,?,?,?,?)',
    [name, initials.toUpperCase(), role, bio, experience, parseInt(sort_order) || 0]);
  req.flash('success', 'Member added.');
  res.redirect('/admin/team');
});
router.post('/team/:id/delete', requireRole('superadmin','admin'), async (req, res) => {
  await db.execute('DELETE FROM team_members WHERE id=?', [req.params.id]);
  req.flash('success', 'Member removed.');
  res.redirect('/admin/team');
});

// ── Jobs CRUD ─────────────────────────────────────────────────
router.get('/jobs', async (req, res) => {
  const [rows] = await db.execute('SELECT * FROM jobs ORDER BY created_at DESC');
  res.render('admin/jobs', {
    title: 'Jobs', user: req.session.user, jobs: rows,
    messages: { success: req.flash('success'), error: req.flash('error') },
  });
});
router.post('/jobs', async (req, res) => {
  const { title, department, location, job_type, description, requirements } = req.body;
  await db.execute('INSERT INTO jobs (title,department,location,job_type,description,requirements) VALUES (?,?,?,?,?,?)',
    [title, department, location, job_type || 'Full-Time', description, requirements]);
  req.flash('success', 'Job posted.');
  res.redirect('/admin/jobs');
});
router.post('/jobs/:id/toggle', async (req, res) => {
  await db.execute('UPDATE jobs SET is_active=NOT is_active WHERE id=?', [req.params.id]);
  res.redirect('/admin/jobs');
});
router.post('/jobs/:id/delete', requireRole('superadmin','admin'), async (req, res) => {
  await db.execute('DELETE FROM jobs WHERE id=?', [req.params.id]);
  req.flash('success', 'Job deleted.');
  res.redirect('/admin/jobs');
});

// ── Blog CRUD ─────────────────────────────────────────────────
router.get('/blog', async (req, res) => {
  const [rows] = await db.execute(
    'SELECT bp.*, u.name AS author_name FROM blog_posts bp LEFT JOIN users u ON u.id=bp.author_id ORDER BY bp.created_at DESC'
  );
  res.render('admin/blog', {
    title: 'Blog Posts', user: req.session.user, posts: rows,
    messages: { success: req.flash('success'), error: req.flash('error') },
  });
});
router.post('/blog', async (req, res) => {
  const { title, slug, category, emoji, excerpt, content, read_time, is_published } = req.body;
  const published = is_published === 'on' ? 1 : 0;
  try {
    await db.execute(
      'INSERT INTO blog_posts (title,slug,category,emoji,excerpt,content,read_time,author_id,is_published,published_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
      [title, slug, category, emoji || '📝', excerpt, content, read_time || '5 min',
       req.session.user.id, published, published ? new Date() : null]);
    req.flash('success', 'Post created.');
  } catch (e) { req.flash('error', 'Slug already exists.'); }
  res.redirect('/admin/blog');
});
router.post('/blog/:id/toggle', async (req, res) => {
  const [[post]] = await db.execute('SELECT is_published FROM blog_posts WHERE id=?', [req.params.id]);
  const now = !post.is_published ? new Date() : null;
  await db.execute('UPDATE blog_posts SET is_published=NOT is_published, published_at=? WHERE id=?', [now, req.params.id]);
  res.redirect('/admin/blog');
});
router.post('/blog/:id/delete', requireRole('superadmin','admin'), async (req, res) => {
  await db.execute('DELETE FROM blog_posts WHERE id=?', [req.params.id]);
  req.flash('success', 'Post deleted.');
  res.redirect('/admin/blog');
});

// ── Settings ──────────────────────────────────────────────────
router.get('/settings', requireRole('superadmin'), async (req, res) => {
  const [rows] = await db.execute('SELECT * FROM settings ORDER BY setting_key');
  const settings = Object.fromEntries(rows.map(r => [r.setting_key, r.setting_val]));
  res.render('admin/settings', {
    title: 'Settings', user: req.session.user, settings,
    messages: { success: req.flash('success'), error: req.flash('error') },
  });
});
router.post('/settings', requireRole('superadmin'), async (req, res) => {
  const entries = Object.entries(req.body);
  for (const [key, val] of entries) {
    await db.execute(
      'INSERT INTO settings (setting_key,setting_val) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_val=?',
      [key, val, val]
    );
  }
  req.flash('success', 'Settings saved.');
  res.redirect('/admin/settings');
});

module.exports = router;
