# IQInfyTech Software Solutions — Node.js Web Application

Production-ready Node.js + Express + MySQL + EJS website with a full admin panel and public-facing corporate website.

---

## Tech Stack

| Layer       | Technology                          |
|-------------|-------------------------------------|
| Runtime     | Node.js 18+                         |
| Framework   | Express 4                           |
| Database    | MySQL 8+ (via mysql2 + connection pool) |
| Views       | EJS templates                       |
| Auth        | bcryptjs + express-session          |
| Security    | helmet, express-validator           |
| Uploads     | multer (resume files)               |
| Logging     | morgan                              |

---

## Project Structure

```
iqinfytech/
├── server.js                  # Main entry point
├── package.json
├── .env.example               # Copy to .env
├── config/
│   └── db.js                  # MySQL connection pool
├── controllers/
│   ├── authController.js      # Login / logout
│   ├── adminController.js     # Dashboard, enquiries, users, applications
│   └── siteController.js      # Public homepage, contact form, job apply
├── middleware/
│   └── auth.js                # requireLogin, requireRole, guestOnly
├── models/                    # (extend here for complex queries)
├── routes/
│   ├── site.js                # Public routes: GET /, POST /contact, POST /apply
│   ├── auth.js                # /admin/login, /admin/logout
│   └── admin.js               # All /admin/* protected routes
├── views/
│   ├── auth/login.ejs         # Login page
│   ├── site/home.ejs          # Public website (all 9 sections)
│   ├── admin/
│   │   ├── dashboard.ejs
│   │   ├── enquiries.ejs
│   │   ├── applications.ejs
│   │   ├── services.ejs
│   │   ├── products.ejs
│   │   ├── portfolio.ejs
│   │   ├── team.ejs
│   │   ├── jobs.ejs
│   │   ├── blog.ejs
│   │   ├── users.ejs
│   │   └── settings.ejs
│   ├── partials/
│   │   ├── admin-header.ejs
│   │   └── admin-footer.ejs
│   └── error.ejs
├── public/
│   ├── css/
│   │   ├── style.css          # Public site styles
│   │   └── admin.css          # Admin panel styles
│   ├── js/
│   │   ├── main.js            # Public JS
│   │   └── admin.js           # Admin JS
│   └── uploads/               # Auto-created on startup
│       └── resumes/           # Uploaded resume files
└── scripts/
    ├── migrate.js             # Creates all database tables
    └── seed.js                # Seeds demo data
```

---

## Quick Start

### 1. Prerequisites
- Node.js 18+
- MySQL 8+

### 2. Clone & Install
```bash
git clone <repo-url>
cd iqinfytech
npm install
```

### 3. Configure Environment
```bash
cp .env.example .env
```
Edit `.env` and set your MySQL credentials:
```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=yourpassword
DB_NAME=iqinfytech_db
SESSION_SECRET=a_long_random_secret_string_here
PORT=3000
NODE_ENV=development
```

### 4. Set Up Database
```bash
# Create tables
node scripts/migrate.js

# Seed with demo data
node scripts/seed.js
```

### 5. Start the Server
```bash
# Development (with nodemon auto-reload)
npm run dev

# Production
npm start
```

### 6. Open in Browser
| URL | Description |
|-----|-------------|
| `http://localhost:3000` | Public website |
| `http://localhost:3000/admin/login` | Admin login |

---

## Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Super Admin | admin@iqinfytech.com | Admin@123 |
| Editor | editor@iqinfytech.com | Admin@123 |

> **Change these immediately in production!**

---

## Admin Panel Features

| Module | Actions |
|--------|---------|
| Dashboard | Stats overview, recent enquiries & applications |
| Enquiries | View contact form submissions, update status |
| Applications | View job applications, update status, download resumes |
| Services | Add / toggle / delete services |
| Products | Add / delete products |
| Portfolio | Add / delete case studies |
| Team | Add / delete team members |
| Jobs | Post / close / delete job openings |
| Blog | Create / publish / delete blog posts |
| Users | Create / enable / disable admin users (superadmin only) |
| Settings | Update site name, contact info, hero content (superadmin only) |

---

## User Roles

| Role | Access |
|------|--------|
| `superadmin` | Full access including users & settings |
| `admin` | All content management (no users/settings) |
| `editor` | View dashboard, manage content (no delete, no users/settings) |

---

## Database Tables

| Table | Purpose |
|-------|---------|
| `users` | Admin users |
| `services` | Website services |
| `products` | Software products |
| `portfolio` | Case studies |
| `team_members` | Team profiles |
| `jobs` | Job openings |
| `job_applications` | Job applications (with optional resume upload) |
| `blog_posts` | Blog articles |
| `enquiries` | Contact form submissions |
| `settings` | Key-value site settings |

---

## Production Deployment

### Environment
Set `NODE_ENV=production` in your `.env`.

### Process Manager (PM2)
```bash
npm install -g pm2
pm2 start server.js --name iqinfytech
pm2 save
pm2 startup
```

### Nginx Reverse Proxy
```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_cache_bypass $http_upgrade;
    }

    location /uploads/ {
        alias /path/to/iqinfytech/public/uploads/;
    }
}
```

### SSL with Certbot
```bash
sudo certbot --nginx -d yourdomain.com
```

---

## Security Notes

- Session cookies are `httpOnly` and `secure` in production
- Passwords hashed with bcrypt (cost factor 12)
- Helmet.js sets secure HTTP headers
- File uploads restricted to 5MB, stored outside web root recommended
- All admin routes behind `requireLogin` middleware
- Role-based access enforced server-side

---

## License

&copy; 2025 IQInfyTech Software Solutions Pvt. Ltd. All rights reserved.
