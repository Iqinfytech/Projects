// middleware/auth.js
exports.requireLogin = (req, res, next) => {
  if (req.session && req.session.user) return next();
  req.flash('error', 'Please log in to access that page.');
  return res.redirect('/admin/login');
};

exports.requireRole = (...roles) => (req, res, next) => {
  if (!req.session || !req.session.user) {
    req.flash('error', 'Please log in.');
    return res.redirect('/admin/login');
  }
  if (!roles.includes(req.session.user.role)) {
    return res.status(403).render('error', {
      title: 'Access Denied',
      code: 403,
      message: 'You do not have permission to access this page.',
      user: req.session.user,
    });
  }
  next();
};

exports.guestOnly = (req, res, next) => {
  if (req.session && req.session.user) return res.redirect('/admin/dashboard');
  next();
};
