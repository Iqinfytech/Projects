// controllers/authController.js
const bcrypt = require('bcryptjs');
const db     = require('../config/db');

exports.getLogin = (req, res) => {
  res.render('auth/login', {
    title:   'Admin Login – IQInfyTech',
    errors:  [],
    old:     {},
    messages: { error: req.flash('error'), success: req.flash('success') },
  });
};

exports.postLogin = async (req, res) => {
  const { email, password } = req.body;
  const errors = [];

  if (!email || !password) {
    errors.push('Email and password are required.');
  }

  if (errors.length) {
    return res.render('auth/login', {
      title:   'Admin Login – IQInfyTech',
      errors,
      old:     { email },
      messages: { error: [], success: [] },
    });
  }

  try {
    const [rows] = await db.execute(
      'SELECT * FROM users WHERE email = ? AND is_active = 1 LIMIT 1',
      [email.trim().toLowerCase()]
    );

    if (!rows.length) {
      return res.render('auth/login', {
        title:   'Admin Login – IQInfyTech',
        errors:  ['Invalid email or password.'],
        old:     { email },
        messages: { error: [], success: [] },
      });
    }

    const user    = rows[0];
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.render('auth/login', {
        title:   'Admin Login – IQInfyTech',
        errors:  ['Invalid email or password.'],
        old:     { email },
        messages: { error: [], success: [] },
      });
    }

    // Update last login
    await db.execute('UPDATE users SET last_login = NOW() WHERE id = ?', [user.id]);

    // Store in session (never store password)
    req.session.user = {
      id:    user.id,
      name:  user.name,
      email: user.email,
      role:  user.role,
    };

    req.flash('success', `Welcome back, ${user.name}!`);
    res.redirect('/admin/dashboard');

  } catch (err) {
    console.error('Login error:', err);
    res.render('auth/login', {
      title:   'Admin Login – IQInfyTech',
      errors:  ['Server error. Please try again.'],
      old:     { email },
      messages: { error: [], success: [] },
    });
  }
};

exports.logout = (req, res) => {
  req.session.destroy(() => {
    res.redirect('/admin/login');
  });
};
