// controllers/siteController.js
const db = require('../config/db');

const getSettings = async () => {
  const [rows] = await db.execute('SELECT setting_key, setting_val FROM settings');
  return Object.fromEntries(rows.map(r => [r.setting_key, r.setting_val]));
};

// ── Home ───────────────────────────────────────────────────────────────────
exports.home = async (req, res) => {
  try {
    const settings                    = await getSettings();
    const [services]                  = await db.execute('SELECT * FROM services WHERE is_active=1 ORDER BY sort_order');
    const [products]                  = await db.execute('SELECT * FROM products WHERE is_active=1 ORDER BY sort_order');
    const [portfolio]                 = await db.execute('SELECT * FROM portfolio WHERE is_active=1 ORDER BY sort_order');
    const [team]                      = await db.execute('SELECT * FROM team_members WHERE is_active=1 ORDER BY sort_order');
    const [jobs]                      = await db.execute('SELECT * FROM jobs WHERE is_active=1 ORDER BY created_at DESC');
    const [blogs]                     = await db.execute(
      'SELECT bp.*, u.name AS author_name FROM blog_posts bp LEFT JOIN users u ON u.id=bp.author_id WHERE bp.is_published=1 ORDER BY bp.published_at DESC LIMIT 4'
    );

    // Parse product features JSON
    products.forEach(p => {
      try { p.features = JSON.parse(p.features || '[]'); } catch { p.features = []; }
    });

    res.render('site/home', {
      title:     settings.site_name || 'IQInfyTech Software Solutions',
      settings, services, products, portfolio, team, jobs, blogs,
      messages:  { success: req.flash('success'), error: req.flash('error') },
    });
  } catch (err) {
    console.error('Home error:', err);
    res.status(500).send('Server error');
  }
};

// ── Contact form submission ────────────────────────────────────────────────
exports.postContact = async (req, res) => {
  const { name, email, phone, company, service, message } = req.body;
  if (!name || !email || !message) {
    req.flash('error', 'Name, email and message are required.');
    return res.redirect('/#contact');
  }
  try {
    await db.execute(
      'INSERT INTO enquiries (name,email,phone,company,service,message) VALUES (?,?,?,?,?,?)',
      [name, email, phone || null, company || null, service || null, message]
    );
    req.flash('success', 'Thank you! We will get back to you within 1 business day.');
  } catch (err) {
    console.error('Contact error:', err);
    req.flash('error', 'Something went wrong. Please try again.');
  }
  res.redirect('/#contact');
};

// ── Job application ────────────────────────────────────────────────────────
exports.postApply = async (req, res) => {
  const { job_id, name, email, phone, cover_letter } = req.body;
  const resumeFile = req.file ? req.file.filename : null;
  if (!name || !email) {
    req.flash('error', 'Name and email are required.');
    return res.redirect('/#careers');
  }
  try {
    await db.execute(
      'INSERT INTO job_applications (job_id,name,email,phone,cover_letter,resume_file) VALUES (?,?,?,?,?,?)',
      [job_id || null, name, email, phone || null, cover_letter || null, resumeFile]
    );
    req.flash('success', 'Application submitted! We will review and get in touch.');
  } catch (err) {
    console.error('Apply error:', err);
    req.flash('error', 'Something went wrong. Please try again.');
  }
  res.redirect('/#careers');
};
