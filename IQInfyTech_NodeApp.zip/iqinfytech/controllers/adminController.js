// controllers/adminController.js
const db = require('../config/db');

exports.dashboard = async (req, res) => {
  try {
    const [[{ services }]]    = await db.execute('SELECT COUNT(*) AS services FROM services WHERE is_active=1');
    const [[{ products }]]    = await db.execute('SELECT COUNT(*) AS products FROM products WHERE is_active=1');
    const [[{ portfolio }]]   = await db.execute('SELECT COUNT(*) AS portfolio FROM portfolio WHERE is_active=1');
    const [[{ jobs }]]        = await db.execute('SELECT COUNT(*) AS jobs FROM jobs WHERE is_active=1');
    const [[{ enquiries }]]   = await db.execute("SELECT COUNT(*) AS enquiries FROM enquiries WHERE status='new'");
    const [[{ applications }]]= await db.execute("SELECT COUNT(*) AS applications FROM job_applications WHERE status='new'");
    const [[{ blogs }]]       = await db.execute('SELECT COUNT(*) AS blogs FROM blog_posts WHERE is_published=1');
    const [[{ team }]]        = await db.execute('SELECT COUNT(*) AS team FROM team_members WHERE is_active=1');

    const [recentEnquiries]   = await db.execute(
      'SELECT * FROM enquiries ORDER BY created_at DESC LIMIT 5'
    );
    const [recentApps]        = await db.execute(
      'SELECT ja.*, j.title AS job_title FROM job_applications ja LEFT JOIN jobs j ON j.id=ja.job_id ORDER BY ja.created_at DESC LIMIT 5'
    );

    res.render('admin/dashboard', {
      title: 'Dashboard',
      user:  req.session.user,
      messages: { success: req.flash('success'), error: req.flash('error') },
      stats: { services, products, portfolio, jobs, enquiries, applications, blogs, team },
      recentEnquiries,
      recentApps,
    });
  } catch (err) {
    console.error(err);
    res.status(500).render('error', { title: 'Error', code: 500, message: 'Server error', user: req.session.user });
  }
};

// ── Enquiries ──────────────────────────────────────────────────────────────
exports.listEnquiries = async (req, res) => {
  const [rows] = await db.execute('SELECT * FROM enquiries ORDER BY created_at DESC');
  res.render('admin/enquiries', {
    title: 'Enquiries', user: req.session.user,
    enquiries: rows,
    messages: { success: req.flash('success'), error: req.flash('error') },
  });
};

exports.updateEnquiryStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  await db.execute('UPDATE enquiries SET status=? WHERE id=?', [status, id]);
  req.flash('success', 'Enquiry status updated.');
  res.redirect('/admin/enquiries');
};

// ── Users ──────────────────────────────────────────────────────────────────
exports.listUsers = async (req, res) => {
  const [rows] = await db.execute('SELECT id,name,email,role,is_active,last_login,created_at FROM users ORDER BY created_at DESC');
  res.render('admin/users', {
    title: 'Users', user: req.session.user, users: rows,
    messages: { success: req.flash('success'), error: req.flash('error') },
  });
};

exports.toggleUser = async (req, res) => {
  const { id } = req.params;
  if (parseInt(id) === req.session.user.id) {
    req.flash('error', 'Cannot deactivate your own account.');
    return res.redirect('/admin/users');
  }
  await db.execute('UPDATE users SET is_active = NOT is_active WHERE id=?', [id]);
  req.flash('success', 'User status updated.');
  res.redirect('/admin/users');
};

exports.createUser = async (req, res) => {
  const { name, email, password, role } = req.body;
  const bcrypt = require('bcryptjs');
  const hash   = await bcrypt.hash(password, 12);
  try {
    await db.execute('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)', [name, email, hash, role]);
    req.flash('success', 'User created.');
  } catch (e) {
    req.flash('error', 'Email already exists.');
  }
  res.redirect('/admin/users');
};

// ── Applications ───────────────────────────────────────────────────────────
exports.listApplications = async (req, res) => {
  const [rows] = await db.execute(
    'SELECT ja.*, j.title AS job_title FROM job_applications ja LEFT JOIN jobs j ON j.id=ja.job_id ORDER BY ja.created_at DESC'
  );
  res.render('admin/applications', {
    title: 'Job Applications', user: req.session.user, applications: rows,
    messages: { success: req.flash('success'), error: req.flash('error') },
  });
};

exports.updateAppStatus = async (req, res) => {
  await db.execute('UPDATE job_applications SET status=? WHERE id=?', [req.body.status, req.params.id]);
  req.flash('success', 'Application status updated.');
  res.redirect('/admin/applications');
};
