// scripts/migrate.js  –  Run: node scripts/migrate.js
require('dotenv').config();
const mysql = require('mysql2/promise');

const SQL = `
CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME || 'iqinfytech_db'}\`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE \`${process.env.DB_NAME || 'iqinfytech_db'}\`;

-- Users (admin login)
CREATE TABLE IF NOT EXISTS users (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(100)  NOT NULL,
  email        VARCHAR(150)  NOT NULL UNIQUE,
  password     VARCHAR(255)  NOT NULL,
  role         ENUM('superadmin','admin','editor') NOT NULL DEFAULT 'editor',
  avatar       VARCHAR(255)  DEFAULT NULL,
  is_active    TINYINT(1)    NOT NULL DEFAULT 1,
  last_login   DATETIME      DEFAULT NULL,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Services
CREATE TABLE IF NOT EXISTS services (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  title        VARCHAR(200)  NOT NULL,
  slug         VARCHAR(220)  NOT NULL UNIQUE,
  icon         VARCHAR(10)   DEFAULT '💻',
  short_desc   TEXT,
  long_desc    TEXT,
  tags         VARCHAR(500),
  sort_order   INT           NOT NULL DEFAULT 0,
  is_active    TINYINT(1)    NOT NULL DEFAULT 1,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Products
CREATE TABLE IF NOT EXISTS products (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(200)  NOT NULL,
  slug         VARCHAR(220)  NOT NULL UNIQUE,
  badge        VARCHAR(100),
  tagline      VARCHAR(500),
  description  TEXT,
  features     TEXT          COMMENT 'JSON array of feature strings',
  sort_order   INT           NOT NULL DEFAULT 0,
  is_active    TINYINT(1)    NOT NULL DEFAULT 1,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Portfolio / Case Studies
CREATE TABLE IF NOT EXISTS portfolio (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  title        VARCHAR(300)  NOT NULL,
  slug         VARCHAR(320)  NOT NULL UNIQUE,
  industry     VARCHAR(100),
  emoji        VARCHAR(10)   DEFAULT '🏢',
  summary      TEXT,
  challenge    TEXT,
  solution     TEXT,
  result_1_val VARCHAR(50),
  result_1_lbl VARCHAR(100),
  result_2_val VARCHAR(50),
  result_2_lbl VARCHAR(100),
  sort_order   INT           NOT NULL DEFAULT 0,
  is_active    TINYINT(1)    NOT NULL DEFAULT 1,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Team members
CREATE TABLE IF NOT EXISTS team_members (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(100)  NOT NULL,
  initials     VARCHAR(4)    NOT NULL,
  role         VARCHAR(150)  NOT NULL,
  bio          TEXT,
  experience   VARCHAR(50),
  linkedin_url VARCHAR(300),
  sort_order   INT           NOT NULL DEFAULT 0,
  is_active    TINYINT(1)    NOT NULL DEFAULT 1,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Job openings
CREATE TABLE IF NOT EXISTS jobs (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  title        VARCHAR(200)  NOT NULL,
  department   VARCHAR(100),
  location     VARCHAR(150),
  job_type     VARCHAR(50)   DEFAULT 'Full-Time',
  description  TEXT,
  requirements TEXT,
  is_active    TINYINT(1)    NOT NULL DEFAULT 1,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Job applications
CREATE TABLE IF NOT EXISTS job_applications (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  job_id       INT           DEFAULT NULL,
  name         VARCHAR(150)  NOT NULL,
  email        VARCHAR(150)  NOT NULL,
  phone        VARCHAR(30),
  cover_letter TEXT,
  resume_file  VARCHAR(300),
  status       ENUM('new','reviewed','shortlisted','rejected') NOT NULL DEFAULT 'new',
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE SET NULL
);

-- Blog posts
CREATE TABLE IF NOT EXISTS blog_posts (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  title        VARCHAR(300)  NOT NULL,
  slug         VARCHAR(320)  NOT NULL UNIQUE,
  category     VARCHAR(100),
  emoji        VARCHAR(10)   DEFAULT '📝',
  excerpt      TEXT,
  content      LONGTEXT,
  read_time    VARCHAR(20)   DEFAULT '5 min',
  author_id    INT           DEFAULT NULL,
  is_published TINYINT(1)    NOT NULL DEFAULT 0,
  published_at DATETIME      DEFAULT NULL,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Contact enquiries
CREATE TABLE IF NOT EXISTS enquiries (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(150)  NOT NULL,
  email        VARCHAR(150)  NOT NULL,
  phone        VARCHAR(30),
  company      VARCHAR(200),
  service      VARCHAR(150),
  message      TEXT          NOT NULL,
  status       ENUM('new','read','replied') NOT NULL DEFAULT 'new',
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Site settings (key-value)
CREATE TABLE IF NOT EXISTS settings (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  setting_key  VARCHAR(100)  NOT NULL UNIQUE,
  setting_val  TEXT,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
`;

async function migrate() {
  let conn;
  try {
    conn = await mysql.createConnection({
      host:     process.env.DB_HOST     || 'localhost',
      port:     process.env.DB_PORT     || 3306,
      user:     process.env.DB_USER     || 'root',
      password: process.env.DB_PASSWORD || '',
      multipleStatements: true,
    });

    const statements = SQL.split(';').map(s => s.trim()).filter(Boolean);
    for (const stmt of statements) {
      await conn.query(stmt);
    }
    console.log('✅  Migration complete — all tables created');
  } catch (err) {
    console.error('❌  Migration error:', err.message);
    process.exit(1);
  } finally {
    if (conn) await conn.end();
  }
}

migrate();
