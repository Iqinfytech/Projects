// scripts/seed.js  –  Run: node scripts/seed.js
require('dotenv').config();
const mysql  = require('mysql2/promise');
const bcrypt = require('bcryptjs');

async function seed() {
  let conn;
  try {
    conn = await mysql.createConnection({
      host:     process.env.DB_HOST     || 'localhost',
      port:     process.env.DB_PORT     || 3306,
      user:     process.env.DB_USER     || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME     || 'iqinfytech_db',
      multipleStatements: true,
    });

    console.log('🌱  Seeding database...');

    // ── Users ──────────────────────────────────────────────────
    const hash = await bcrypt.hash('Admin@123', 12);
    await conn.query(`
      INSERT IGNORE INTO users (name, email, password, role) VALUES
      ('Super Admin', 'admin@iqinfytech.com', ?, 'superadmin'),
      ('Content Editor', 'editor@iqinfytech.com', ?, 'editor')
    `, [hash, hash]);
    console.log('  ✓ Users');

    // ── Services ───────────────────────────────────────────────
    await conn.query(`INSERT IGNORE INTO services
      (title, slug, icon, short_desc, tags, sort_order) VALUES
      ('AI / Machine Learning', 'ai-machine-learning', '🧠',
       'Build intelligent systems with predictive analytics, NLP, computer vision, and generative AI. We design, train, and deploy production-grade ML models tailored to your domain.',
       'LLM Integration,MLOps,GenAI,AutoML', 1),
      ('Custom Software Development', 'custom-software-development', '💻',
       'Tailor-made web, desktop, and API solutions built with modern stacks. Full SDLC ownership from requirements to deployment and ongoing support.',
       'React / Node,.NET / Java,Microservices', 2),
      ('Cloud Solutions', 'cloud-solutions', '☁️',
       'Architect, migrate, and optimize cloud infrastructure on AWS, Azure, and GCP. High availability, security, and cost efficiency at every layer.',
       'AWS,Azure,GCP,DevOps / CI-CD', 3),
      ('Mobile App Development', 'mobile-app-development', '📱',
       'Cross-platform and native iOS/Android applications with seamless UX. From consumer apps to enterprise mobility solutions.',
       'React Native,Flutter,Swift / Kotlin', 4),
      ('ERP / CRM Implementation', 'erp-crm-implementation', '🏗️',
       'SAP, Salesforce, Oracle, and custom ERP/CRM rollouts. Implementation, customisation, data migration, and change management.',
       'Salesforce,SAP S/4HANA,Oracle', 5),
      ('Data Analytics & BI', 'data-analytics-bi', '📊',
       'Transform raw data into actionable intelligence with data warehousing, ETL pipelines, real-time dashboards, and advanced analytics platforms.',
       'Power BI,Snowflake,Apache Spark', 6),
      ('IT Consulting', 'it-consulting', '🔧',
       'Strategic technology advisory including digital transformation roadmaps, architecture reviews, vendor selection, and technology due diligence.',
       'Digital Transformation,Architecture,Due Diligence', 7)
    `);
    console.log('  ✓ Services');

    // ── Products ───────────────────────────────────────────────
    await conn.query(`INSERT IGNORE INTO products
      (name, slug, badge, tagline, description, features, sort_order) VALUES
      ('IQ-BankCore Pro', 'iq-bankcore-pro', 'BFSI Platform',
       'End-to-end core banking modernisation',
       'End-to-end core banking migration and modernisation platform with real-time processing and regulatory compliance built in.',
       '["Multi-currency & multi-entity support","Real-time transaction processing engine","Built-in RBI / SEBI compliance modules","Open banking API layer — PSD2 ready","Seamless CBS migration toolkit"]',
       1),
      ('IQ-Insights AI', 'iq-insights-ai', 'AI Suite',
       'Enterprise AI analytics at scale',
       'Enterprise AI analytics platform with prebuilt connectors, AutoML, and natural language querying for business intelligence at scale.',
       '["Drag-and-drop ML model builder","NLP-powered report generation","Real-time anomaly detection","200+ pre-built data connectors","Role-based access & audit trail"]',
       2),
      ('IQ-MobileSuite', 'iq-mobilesuite', 'Enterprise Mobility',
       'Low-code enterprise mobility platform',
       'Low-code platform for rapid deployment of field operations, CRM, and workflow management apps across all devices.',
       '["Visual app builder — no-code / low-code","Offline-first architecture","Biometric & SSO authentication","Push notifications & geofencing","MDM integration support"]',
       3)
    `);
    console.log('  ✓ Products');

    // ── Portfolio ──────────────────────────────────────────────
    await conn.query(`INSERT IGNORE INTO portfolio
      (title, slug, industry, emoji, summary, result_1_val, result_1_lbl, result_2_val, result_2_lbl, sort_order) VALUES
      ('Core Banking Migration for Regional Co-operative Bank', 'core-banking-migration',
       'Banking & Finance', '🏦',
       'Migrated 1.2M customer records from legacy CBS to cloud-native platform with zero data loss and under 4 hours total downtime.',
       '99.9%', 'Uptime post-go-live', '60%', 'Ops cost reduction', 1),
      ('SAP ERP Implementation for Auto-Parts Manufacturer', 'sap-erp-manufacturing',
       'Manufacturing', '🏭',
       'End-to-end SAP S/4HANA rollout across 6 plants integrating procurement, inventory, and production planning in 9 months.',
       '35%', 'Inventory reduction', '9 mo', 'Delivery timeline', 2),
      ('AI-Powered Demand Forecasting Platform', 'ai-demand-forecasting',
       'Retail & E-commerce', '🛒',
       'Custom ML pipeline for a D2C brand forecasting demand across 50,000+ SKUs with 91% accuracy, cutting wastage significantly.',
       '91%', 'Forecast accuracy', '28%', 'Wastage reduction', 3),
      ('Patient Engagement Mobile App for Hospital Chain', 'patient-engagement-app',
       'Healthcare', '🏥',
       'Cross-platform app for appointment booking, teleconsultation, and lab reports. 120K+ downloads in first 6 months.',
       '120K+', 'Downloads (6 months)', '4.8★', 'App store rating', 4),
      ('AWS Cloud Migration for Insurance Aggregator', 'aws-cloud-insurance',
       'Insurance', '☁️',
       'Lifted monolithic on-prem system to AWS microservices, achieving 3× faster page loads and 45% infrastructure cost savings.',
       '3×', 'Faster page loads', '45%', 'Infra cost savings', 5),
      ('Real-Time Sales Analytics for FMCG Brand', 'fmcg-sales-analytics',
       'FMCG', '📊',
       'Unified BI platform aggregating POS, distributor, and e-commerce data for real-time sales visibility across 5,000+ retail points.',
       '5K+', 'Retail points tracked', 'Real-time', 'Sales visibility', 6)
    `);
    console.log('  ✓ Portfolio');

    // ── Team ───────────────────────────────────────────────────
    await conn.query(`INSERT IGNORE INTO team_members
      (name, initials, role, bio, experience, sort_order) VALUES
      ('Rajesh Kumar',  'RK', 'Founder & CEO',
       '20+ yrs leading enterprise tech transformations across BFSI and manufacturing sectors globally.', '20+ yrs', 1),
      ('Priya Desai',   'PD', 'Chief Technology Officer',
       'Ex-Microsoft engineer and architect of cloud-native platforms, passionate about AI and distributed systems.', '18+ yrs', 2),
      ('Arjun Mehta',   'AM', 'VP – AI & Data',
       'PhD Computer Science, specialises in ML model deployment, NLP, and large-scale data engineering.', '14+ yrs', 3),
      ('Sunita Nair',   'SN', 'VP – Delivery',
       'PMP certified with a track record of managing 80+ cross-functional projects on time and on budget.', '15+ yrs', 4)
    `);
    console.log('  ✓ Team');

    // ── Jobs ───────────────────────────────────────────────────
    await conn.query(`INSERT IGNORE INTO jobs
      (title, department, location, job_type) VALUES
      ('Senior AI / ML Engineer',              'Engineering',  'Mumbai / Remote',    'Full-Time'),
      ('Cloud Solutions Architect (AWS/Azure)', 'Cloud',        'Pune / Remote',      'Full-Time'),
      ('React Native Mobile Developer',         'Mobile',       'Bengaluru',          'Full-Time'),
      ('SAP S/4HANA Functional Consultant',     'ERP',          'Mumbai / Client Sites','Full-Time'),
      ('Business Development Manager – BFSI',  'Sales',        'Mumbai',             'Full-Time')
    `);
    console.log('  ✓ Jobs');

    // ── Blog posts ─────────────────────────────────────────────
    const adminId = (await conn.query(`SELECT id FROM users WHERE email='admin@iqinfytech.com' LIMIT 1`))[0][0]?.id || 1;
    await conn.query(`INSERT IGNORE INTO blog_posts
      (title, slug, category, emoji, excerpt, read_time, author_id, is_published, published_at) VALUES
      ('How GenAI Is Reshaping Core Banking Operations in 2025',
       'genai-core-banking-2025', 'AI & Machine Learning', '🤖',
       'From intelligent fraud detection to AI-assisted customer onboarding, generative AI is now production-grade in BFSI.',
       '8 min', ?, 1, '2025-06-10'),
      ('Zero-Downtime Cloud Migration: A Practical Playbook',
       'zero-downtime-cloud-migration', 'Cloud & Infrastructure', '☁️',
       'Lessons from migrating 40+ enterprise workloads to AWS and Azure — what worked, what failed, and what we would do differently.',
       '12 min', ?, 1, '2025-05-28'),
      ('React Native vs Flutter in 2025: An Enterprise Developer View',
       'react-native-vs-flutter-2025', 'Mobile Development', '📱',
       'A no-hype comparison of the two dominant cross-platform frameworks based on real project experience at scale.',
       '9 min', ?, 1, '2025-05-14'),
      ('Building a Modern Data Lakehouse: Architecture Patterns That Scale',
       'data-lakehouse-architecture', 'Data & Analytics', '📊',
       'How leading enterprises are unifying batch and streaming data with Medallion architecture on Snowflake and Delta Lake.',
       '11 min', ?, 1, '2025-04-30')
    `, [adminId, adminId, adminId, adminId]);
    console.log('  ✓ Blog posts');

    // ── Settings ───────────────────────────────────────────────
    await conn.query(`INSERT IGNORE INTO settings (setting_key, setting_val) VALUES
      ('site_name',        'IQInfyTech Software Solutions Pvt. Ltd.'),
      ('site_email',       'hello@iqinfytech.com'),
      ('site_phone',       '+91 22 6700 0000'),
      ('site_address',     'IQInfyTech Tower, Bandra Kurla Complex, Mumbai 400051'),
      ('hero_title',       'Engineering Intelligent Software Solutions'),
      ('hero_subtitle',    'IQInfyTech builds enterprise-grade software — from AI-powered platforms to cloud migrations — that transform how businesses operate and scale.'),
      ('stat_projects',    '200+'),
      ('stat_clients',     '85+'),
      ('stat_years',       '12')
    `);
    console.log('  ✓ Settings');

    console.log('\n🎉  Seed complete!');
    console.log('   Admin login → admin@iqinfytech.com / Admin@123');

  } catch (err) {
    console.error('❌  Seed error:', err.message);
    process.exit(1);
  } finally {
    if (conn) await conn.end();
  }
}

seed();
